== GhostPCL ==

This is a build of the GhostPCL document conversion engine for
Microsoft Windows. The pcl6.exe executable handles files in the
PCL/XL language family.

These GhostPDL builds are command-line tools. You'll need to invoke
them from an MS-DOS/Windows command prompt. For example:

  pcl6.exe frs96.pxl

GhostPCL is distributed under the terms of the GNU GPL. See the file
COPYING for details. Source code and other binaries can be obtained
from http://ghostscript.com/

The pcl6.exe executable contains fonts from URW and these are
necessary for proper function of the PCL interpreter, but they are
NOT FREE SOFTWARE and are not distributed under the GPL. Instead
they are distributed under the AFPL license which explicitly
prohibits commercial use. See the file COPYING.AFPL for details.

GhostPCL, GhostXPS, Ghostscript and the urw font set are also
available for commercial licensing under other terms. Please visit
http://artifex.com/ for more information.
